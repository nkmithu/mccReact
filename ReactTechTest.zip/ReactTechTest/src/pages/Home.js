import React from 'react';
import  NavBar  from '../components/NavBar';
import {Container, Row, Col} from 'react-bootstrap';
import InputForm from '../components/InputForm/InputForm';
import UserData from '../components/UserData/UserData';
const Home = () => {
    return (
        <div>
            <Container>
                <Row>
                    <Col>
                      <NavBar/>
                      <InputForm/>
                      <UserData/>
                     </Col>
                </Row>
            </Container>
           
        </div>
    );
};

export default Home;