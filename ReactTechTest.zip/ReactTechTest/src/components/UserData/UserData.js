import React, { useEffect, useState } from 'react';
import SingleUserData from '../SingleUserData/SingleUserData';
import './UserData.css';

const UserData = () => {

    const [users, setUsers]= useState([]);

    useEffect(()=>{
        fetch('https://jsonplaceholder.typicode.com/users')
        .then(res=>res.json())
        .then(data => setUsers(data));
    }, [])
    return (
        <div className="card-container">
            { users.map(user=> <SingleUserData key={user.id} user = {user}></SingleUserData>)
                
            }
        </div>
        
    );
};

export default UserData;