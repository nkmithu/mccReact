import React from 'react';
import {Card, Button} from 'react-bootstrap';
import './SIngleUserData.css';

const SingleUserData = ({user}) => {
    const{id, name, email, phone, address} = user;
    return (
        <Card style={{ width: '18rem' }} className="user-card">
        <Card.Body>
            <Card.Title>Name: {name}</Card.Title>
            <p>ID : {id}</p>
            <p>Email : {email}</p>
            <p>Phone : {phone}</p>
            <p>Address : {address.stret} {address.street} {address.suite} {address.stret} {address.city}</p>
            <Button variant="primary">Go somewhere</Button>
        </Card.Body>
    </Card>
    );
};

export default SingleUserData;