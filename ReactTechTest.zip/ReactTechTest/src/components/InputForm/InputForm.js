import React, { useState } from 'react';
import './InputForm.css';
import {Form, Button,Table} from 'react-bootstrap';
const InputForm = () => {
    
    const [formData, setFormData] = useState({email:"", phone:""});

    const handleOnSubmit =(e)=>{
        e.preventDefault();
            console.log(e.target.value);
    }
    
    const  validateEmail = (email)=> {   
        let re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }
    const validatePhone = (phone)=>{
        let re = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
        return re.test(phone);
    }
    const handleOnBlur = (e)=>{
        console.log(e.target.value);
        const newFormData = {...formData};
        if(e.target.name = "email"){
            let email = e.target.value;
            if (validateEmail(email)){
                newFormData.email = email;
            } else{
                alert("Type a valid email adress");
            }
        }
        if(e.target.name = "phone"){
            newFormData.phone = e.target.value;
            console.log(newFormData);
        }
        
        

        return setFormData(newFormData);
      
    }
    

    return (
        
        <div>
            <Form className="input_form" onSubmit={handleOnSubmit}>
                <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control name ="email" type="email" placeholder="Enter email" onBlur={handleOnBlur} />
                </Form.Group>

                <Form.Group controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control name="phone" type="text" placeholder="Phone Number" onBlur={handleOnBlur} />
                </Form.Group>
                <Button variant="primary" type="submit">
                    Submit
                </Button>
            </Form>

            <Table striped bordered hover>
                    <thead>
                        <tr>
                        <th>Email</th>
                        <th>Phone Number</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <td>{formData.email}</td>
                        <td>{formData.phone}</td>
                        </tr>
                    </tbody>
            </Table>
        </div>
    );
};

export default InputForm;